$(function(){
    // Arrastar
    $('.drag').draggable({
        // Conecta com a função de reordenar
        connectToSortable: '.drop-container',
        helper: 'clone'
    });

    // Soltar e reordenar
    $('.drop-container').sortable({
        placeholder: 'placeholder',
        activate: function(event, ui){
            $('.drop-container p').remove();
        }
    });

    // Lixeira
    $('.lixeira').droppable({
        hoverClass: 'lixeira-ativa',
        drop: function(event, ui) {
            $(ui.draggable).remove();
        }
    });

    // Salvar
    $('.salvar').click(function(){
        var valores = new Array();

        $('.drop-container .drag').each(function(){
            valores.push( $(this).html() );
        });

        // Faça o que preferir com os valores
        alert(valores);
    });
});
