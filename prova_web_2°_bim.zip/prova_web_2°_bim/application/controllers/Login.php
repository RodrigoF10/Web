<?php defined('BASEPATH') OR exit('No direct script acess allow');
	class Login extends CI_Controller{

		public function __construct(){
			parent::__construct();
			$this->load->library('session');
		}

		public function index(){
			$this->load->library('session');
			$this->load->helper('form');
			$this->load->view('login');
		}

		public function efetuar_login(){
			$this->load->library('session');
			$usuario = $this->input->post('txt_usuario');
			$senha = $this->input->post('txt_senha');
			if($usuario=="rodrigo" and $senha == "rodrigo"){
				$array=array("logado"=>true);
				$this->session->set_userdata($array);
				$this->load->view('tela_inicial');
			}else{
				$this->session->sess_destroy();
				redirect("login");
			}
		}

		public function logout(){
			$this->load->library('session');
			$this->session->sess_destroy();
			redirect("login");
		}
	}
