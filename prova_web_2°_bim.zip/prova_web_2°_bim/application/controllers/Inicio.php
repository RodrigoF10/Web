<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inicio extends CI_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->library('session');
			if(!$this->session->userdata('logado')){
				redirect("login");
			}
		}

	public function cadastro_bandas(){
		$this->load->view('cadastrar');
	}

	public function fim_cadastro(){
		$data['nome'] = $this->input->post('txt_nome');
		$data['data_fundacao'] = $this->input->post('txt_data');
		$data['quant_integrantes'] = $this->input->post('txt_integrantes');
		if($this->db->insert('rock', $data)){
			$this->load->view('tela_inicial');
		}else{
			echo "Nao foi possivel gravar a postagem";
		}
	}

	public function atualizar_dados(){
		$data['dados'] = $this->db->get('rock')->result();
		$this->load->view('opcoes_atualizar', $data);
	}

	public function alterar($id){
		$this->db->where('id', $id);
		$data['banda'] = $this->db->get('rock')->result();
		$this->load->helper('form');
		$this->load->view('alterar_select', $data);
	}

	public function salvar_alteracao(){
		$data['nome'] = $this->input->post('txt_nome');
		$data['data_fundacao'] = $this->input->post('txt_data');
		$data['quant_integrantes'] = $this->input->post('txt_integrantes');
		$this->db->where('id', $this->input->post('id'));
		if($this->db->update('rock', $data)){
			$this->load->view('tela_inicial');
		}else{
			echo "Nao foi possivel gravar a altereação";
		}
	}

	public function excluir_banda(){
		$data['dados'] = $this->db->get('rock')->result();
		$this->load->view('opcoes_excluir', $data);
	}

	public function excluir($id){
			$this->db->where('id', $id);
			if($this->db->delete('rock')){
				$this->load->view('tela_inicial');
			}else{
				echo "nao foi possivel excluir";
			}
	}

	public function listar_bandas(){
		$data['dados'] = $this->db->get('rock')->result();
		$this->load->view('listar', $data);
	}

	public function gerar_relatorio(){
		$data['banda'] = $this->db->get('rock')->result();
		$this->load->helper('form');
		$this->load->view('geraPdf', $data);
	}

	public function voltar(){
		$this->load->view('tela_inicial');
	}

}
