<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Atualizar</title>
		<?php
			echo link_tag('assets/css/bootstrap.min.css');
		?>
		<script src="../../assets/js/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src='../../assets/js/bootstrap.min.js' type="text/javascript"></script>
		<?php
				echo link_tag('assets/css/select_atu.css');
		?>
	</head>
	<body>
		<h1>ALTERAR<H1>
		<br><br>
		<h2>ESCOLHA A BANDA QUE DESEJA ALTERAR<h2>
		<div class="container">
				<div class="row">
					<div class="btn btn-default">
		    		<?php
		        	foreach($dados as $post) {
		            	echo anchor(base_url("Inicio/alterar/".$post->id), " Alterar " . $post->nome) . br() . br();
		        	}
							echo form_open(base_url('Inicio/voltar')) .
							form_submit("btn_voltar","Voltar") . form_close();
						?>
					</div>
				</div>
		</div>
	</body>
</html>
