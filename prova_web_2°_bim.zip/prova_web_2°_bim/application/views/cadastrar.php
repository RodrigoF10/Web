<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link type="text/css" href="../../assets/jsc/jquery-ui.css" rel="stylesheet" />
		<script type="text/javascript" src="../../assets/jsc/jquery-2.1.1.min.js"></script>
		<script type="text/javascript" src="../../assets/jsc/jquery-ui.js"></script>
		<script type="text/javascript" src="../../assets/jsc/datepicker-pt-BR.js"></script>
		<title>Selecionar-cadastro</title>
		<?php
				echo link_tag('assets/css/cadastrar.css');
		?>
	</head>
	<body>
		<h1>CADASTRO DE BANDAS</h1>
		<?php
			$atributos = array('name'=>'formulario_login', 'id'=>'formulario_cadastro');
			echo form_open(base_url('Inicio/fim_cadastro'), $atributos);
			$data = array('name'=>'txt_data', 'id'=>'data_1');
			echo
			form_label("Nome: ", "txt_nome").br().
			form_input('txt_nome').br().
			form_label("Data de Fundação: ").br().
			form_input($data).br().
			form_label("Quantidade de Integrantes: ", "txt_integrantes").br().
			form_input('txt_integrantes').br(). br() .
			form_submit("btn_enviar", "Cadastrar").form_close();
			echo form_open(base_url('Inicio/voltar'),$atributos) .
			form_submit("btn_voltar","Voltar") . form_close();
		?>
		<script>
		$(function() {
			$("#data_1").datepicker({
				changeMonth: true,
				changeYear: true
			
			});
		});
		</script>
	</body>
</html>
