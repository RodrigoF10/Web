<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link>
		<title>Realize o seu Login</title>
		<?php
			echo link_tag('assets/css/bootstrap.min.css');
		?>
		<script src="../../assets/js/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src='../../assets/js/bootstrap.min.js' type="text/javascript"></script>
		<?php
				echo link_tag('assets/css/estilo_login.css');
		?>
	</head>
	<body>
		<div class="row">
			<div id="conteudo" class="col-md-12">
				<?php
					$atributos = array('name'=>'formulario_login', 'id'=>'formulario_login');
					echo form_open(base_url('login/efetuar_login'), $atributos).
					form_label("Usuario: ", "txt_usuario").br().
					form_input('txt_usuario').br().
					form_label("Senha: ", "txt_senha").br().
					form_password('txt_senha').br().
					form_submit("btn_enviar", "Efetuar Login").form_close();
				?>
			</div>
		</div>

	</body>
</html>
