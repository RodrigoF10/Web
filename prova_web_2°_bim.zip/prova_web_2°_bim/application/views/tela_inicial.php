<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Página Inicial</title>
		<?php
			echo link_tag('assets/css/bootstrap.min.css');
		?>
		<script src="../../assets/js/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src='../../assets/js/bootstrap.min.js' type="text/javascript"></script>
		<?php
				echo link_tag('assets/css/pagina_inicial.css');
		?>
	</head>
	<body>
		<h1>ESCOLHA O QUE DESEJA FAZER</h1>
		<div class="row">
			<div id="conteudo" class="col-md-12">
				<div class="row">
						<div class="btn btn-default">
								<?php
									echo anchor(("Inicio/cadastro_bandas"), "Cadadastrar Bandas") . br();
								 ?>
						</div>
				</div>
				<br>
				<div class="row">
						<div class="btn btn-default">
								<?php
									echo anchor(base_url("Inicio/atualizar_dados"), "Atualizar Dados Bandas") . br();
								 ?>
						</div>
				</div>
				<br>
				<div class="row">
						<div id="botao" class="btn btn-default">
								<?php
									echo anchor(base_url("Inicio/excluir_banda"), "Excluir Banda") . br();
								 ?>
						</div>
				</div>
				<br>
				<div class="row">
						<div id="botao" class="btn btn-default">
								<?php
									 echo anchor(base_url("Inicio/listar_bandas"), "Listar Bandas Cadastradas") . br();
								 ?>
						</div>
				</div>
				<br>
				<div class="row">
						<div class="btn btn-default">
								<?php
									 echo anchor(base_url("Inicio/gerar_relatorio"), "Gerar PDF com todas as bandas") . br();
								 ?>
						</div>
				</div>
				<br>
				<div class="row">
						<div class="btn btn-default">
							<div class="col-md-12">
								<?php
									 echo anchor(base_url("Login/logout"), "Logout");
								 ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
