<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Alterar</title>
		<link type="text/css" href="../../assets/jsc/jquery-ui.css" rel="stylesheet" />
		<script type="text/javascript" src="../../assets/jsc/jquery-2.1.1.min.js"></script>
		<script type="text/javascript" src="../../assets/jsc/jquery-ui.js"></script>
		<script type="text/javascript" src="../../assets/jsc/datepicker-pt-BR.js"></script>
		<?php
				echo link_tag('assets/css/alterar_select.css');
		?>
	</head>
	<body>
		<h1>SELECIONE OS VALORES QUE DESEJA ALTERAR</h1>
		<?php
			$atributos = array('name'=>'formulario_postagem', 'id'=>'formulario_alterar');
			echo form_open(base_url('Inicio/salvar_alteracao'), $atributos);
			$data = array('name'=>'txt_data', 'id'=>'data_1');
			echo
			form_hidden('id', $banda[0]->id).
			form_label("Nome: ", "txt_nome").br().
			form_input('txt_nome', $banda[0]->nome).br().
			form_label("Data de fundação: ").br().
			form_input($data, $banda[0]->data_fundacao).br().
			form_label("Quantidade Integrantes: ", "txt_integrantes").br().
			form_input('txt_integrantes', $banda[0]->quant_integrantes).br(). br() .
			form_submit("btn_enviar", "Salvar Postagem").form_close();
			echo form_open(base_url('Inicio/voltar'),$atributos) .
			form_submit("btn_voltar","Voltar") . form_close();
		?>
		<script>
			$(function() {
				$("#data_1").datepicker({
					changeMonth: true,
					changeYear: true
				
				});
			});
		</script>
	</body>
</html>
