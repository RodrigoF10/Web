<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Listar</title>
			<?php
				echo link_tag('assets/css/bootstrap.min.css');
			?>
			<script src="../../assets/js/jquery-3.2.0.min.js" type="text/javascript"></script>
			<script src='../../assets/js/bootstrap.min.js' type="text/javascript"></script>
			<?php
					echo link_tag('assets/css/opcoes_excluir.css');
			?>
	</head>
	<body>
		<h1>BANDAS CADASTRADAS<h1>
		<div class="container">
			<div class="row">
				<div class="btn btn-default">
			    <?php
			        foreach($dados as $post) {
			            echo  " Nome: " . $post->nome. " Data de Fundação: " . $post->data_fundacao . " Quantidade de Integrantes: " . $post->quant_integrantes . br() . br();
			        }
							echo form_open(base_url('Inicio/voltar')) .
							form_submit("btn_voltar","Voltar") . form_close();
			    ?>
				</div>
			</div>
	</div>
	</body>
</html>
