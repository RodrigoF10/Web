<?php
	include_once "assets/fpdf/fpdf.php";
	
	//cria matriz com os titulos 
	//e argura das colunas
	$titulos = array(
		utf8_decode('Nome'), 
		utf8_decode('Quantidade Integrantes'),
		utf8_decode('Data Fundação')
	);
	$larguras = array(200, 160, 200);
	$dados = array();
	foreach($banda as $post){
		$dados[] = array(utf8_decode($post->nome),$post->data_fundacao,$post->quant_integrantes);
	}
	
	$pdf = new FPDF('P', 'pt', 'A4');
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 12);
	
	//cor de preenchimento e espessura de linha
	$pdf->SetFillColor(130, 80, 70);
	$pdf->SetTextColor(255);
	$pdf->SetLineWidth(1);
	
	//criar o cabeçalo da tabela
	$i = 0;
	foreach($titulos as $key){
		$pdf->Cell($larguras[$i], 15, $key, 1, 0, 'C', true);
		$i++;
	}
	
	//quebra de linha
	$pdf->Ln();
	$pdf->SetFillColor(200, 200, 200);
	$pdf->SetTextColor(0);
	$pdf->SetFont('Arial', '', 12);
	
	//adiciona os dados
	$colore = false;
	$total = 0;
	foreach($dados as $linha){
		$col = 0;
		foreach($linha as $coluna){
			//se inteiro alinha a direita 
			if(is_int($coluna)){
				$pdf->Cell($larguras[$col], 14, number_format($coluna), 'LR', 0, 'R', $colore);
			}else{
				$pdf->Cell($larguras[$col], 14, $coluna, 'LR', 0, 'L', $colore);
			}
			$col++;
		}
		$pdf->Ln();
		$colore = !$colore;
	}
	
	//define a fonte dos totais
	$pdf->SetFont('Arial', 'B', 12);
	
	
	$pdf->OutPut();
?>
